let progress = 35;
let eta = 18;
const logDiv = document.getElementById("log");

function log(msg) {
    const time = new Date().toLocaleTimeString();
    logDiv.innerHTML += `[${time}] ${msg}<br>`;
    logDiv.scrollTop = logDiv.scrollHeight;
}

function updateLoc() {
    fetch("/update_location", { method: "POST" })
        .then(r => r.json())
        .then(d => {
            document.getElementById("location").textContent = d.location;
            progress = d.progress;
            eta = d.eta;
            document.getElementById("progressBar").style.width = progress + "%";
            document.getElementById("progressBar").textContent = progress + "%";
            document.getElementById("eta").textContent = `ETA: ${eta} min`;
            log("🚗 GPS updated • Car moving at 42 km/h");
            document.getElementById("car").style.animation = "none";
            setTimeout(() => document.getElementById("car").style.animation = "drive 2s linear infinite", 10);
        });
}

function delay() {
    fetch("/delay", { method: "POST" })
        .then(() => {
            Swal.fire("🚨 Delay", "Driver Thabo delayed 7 min (M4 traffic)\nNotification sent to you", "warning");
            log("🚨 DELAY ALERT sent • ETA now 25 min");
            document.getElementById("eta").textContent = "ETA: 25 min ⏳";
        });
}

function wrong() {
    fetch("/wrong_route", { method: "POST" })
        .then(() => {
            Swal.fire("🛣️ Wrong Route!", "Driver went wrong way!\nAuto-rerouted • You were notified", "error");
            log("🛣️ WRONG ROUTE ALERT • Corrected • Passenger notified");
        });
}

function cancelR() {
    Swal.fire({
        title: "Cancel this ride?",
        text: "You (Londeka) want to cancel",
        icon: "question",
        showCancelButton: true,
        confirmButtonColor: "#d33"
    }).then(res => {
        if (res.isConfirmed) {
            fetch("/cancel", { method: "POST" })
                .then(() => {
                    Swal.fire("✅ Cancelled!", "Ride cancelled • Driver notified • Refund in 5 min", "success");
                    log("❌ RIDE CANCELLED by you");
                    setTimeout(() => location.reload(), 2500);
                });
        }
    });
}

function endR() {
    fetch("/end_ride", { method: "POST" })
        .then(() => {
            Swal.fire("🎉 Safe Arrival!", "Thank you for using Track Shuffle ❤️\nYou helped reduce DUT traffic today!", "success");
            log("🏁 Ride completed • 4.9 ⭐ sent");
            setTimeout(() => location.reload(), 3000);
        });
}

// Auto demo
setInterval(() => { if (Math.random() > 0.4) updateLoc(); }, 4500);

log("🔥 Track Shuffle loaded • Connected to DUT server • Ready for students & staff");