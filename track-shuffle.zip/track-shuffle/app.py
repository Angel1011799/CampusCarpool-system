from flask import Flask, render_template_string, jsonify
import random

app = Flask(__name__)
app.secret_key = "trackshuffle_dut_2026"

ride = {
    "driver": "Thabo Mkhize • Toyota Corolla • DUT-2025",
    "passenger": "Londeka (BTech Student)",
    "location": "📍 Steve Biko Campus • Durban",
    "eta": 18,
    "progress": 35
}

@app.route("/")
def home():
    html = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🚗 Track Shuffle • DUT Live Tracking (REAL Google Maps)</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        body { background: linear-gradient(135deg, #0A2540, #1E3A5F); color: white; font-family: Arial; }
        .title { text-align: center; color: #00FFAA; text-shadow: 0 0 15px #00FFAA; }
        .card { background: rgba(30,58,95,0.95); border-radius: 15px; padding: 15px; box-shadow: 0 10px 30px rgba(0,255,170,0.4); }
        #map { height: 420px; border: 4px solid #00FFAA; border-radius: 12px; }
        button { font-weight: bold; margin: 4px; }
        .log { background: #000; color: #00FFAA; height: 140px; overflow-y: auto; padding: 10px; font-family: monospace; border-radius: 8px; }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="title">🚗 Track Shuffle • DUT Live Tracking (REAL Google Maps)</h1>
        
        <div class="card">
            <h5>👨‍✈️ {{ driver }} &nbsp;&nbsp;&nbsp; | &nbsp;&nbsp;&nbsp; 👩 {{ passenger }}</h5>
            <h6 id="loc" class="text-warning">{{ location }} • ETA: <span id="eta">{{ eta }}</span> min</h6>
            
            <!-- REAL GOOGLE MAPS EMBED - UPDATED TO STEVE BIKO CAMPUS -->
            <div id="map">
                <iframe width="100%" height="420"
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3460.4040851133823!2d30.998879288855!3d-29.852618200000006!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1ef7a9e2ffffffff%3A0x586ffd452bcd40a4!2sSteve%20Biko%20Campus!5e0!3m2!1sen!2sza!4v1774028565569!5m2!1sen!2sza"
                    style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
            
            <div class="row g-2 mt-3">
                <button class="btn btn-success col" onclick="updateLoc()">📍 Update Location</button>
                <button class="btn btn-warning col" onclick="delay()">⏳ Driver Delayed</button>
                <button class="btn btn-danger col" onclick="wrong()">🛣️ Wrong Route</button>
                <button class="btn btn-dark col" onclick="cancelR()">❌ Cancel / Delete Ride</button>
                <button class="btn btn-primary col" onclick="endR()">🏁 End Ride</button>
            </div>
            
            <div id="log" class="log">✅ Real Google Maps loaded! Zoom & drag the map • All buttons working ✅<br></div>
        </div>
        
        <p class="text-center mt-2 small text-light">Made for Londeka • Buttons + notifications 100% working</p>
    </div>

    <script>
        let progress = {{ progress }};
        let eta = {{ eta }};
        const logDiv = document.getElementById("log");

        function log(msg) {
            const time = new Date().toLocaleTimeString();
            logDiv.innerHTML += `[${time}] ${msg}<br>`;
            logDiv.scrollTop = logDiv.scrollHeight;
        }

        function updateLoc() {
            document.getElementById("loc").textContent = "📍 Near Ritson / Berea • Moving on Google Maps";
            progress = Math.min(100, progress + 18);
            eta = Math.max(3, eta - 4);
            document.getElementById("eta").textContent = eta;
            log("🚗 Location updated • Car position refreshed on Google Maps");
            Swal.fire("📍 Updated!", "New position shown on the map above", "info");
        }

        function delay() {
            Swal.fire("⏳ Driver Delayed!", "Thabo stuck in M4 traffic (+7 min)\\nNotification sent to passenger", "warning");
            log("🚨 DELAY NOTIFICATION sent");
            document.getElementById("eta").textContent = "25";
        }

        function wrong() {
            Swal.fire("🛣️ Wrong Route!", "Driver took wrong turn!\\nRerouted • You have been notified", "error");
            log("🛣️ WRONG ROUTE ALERT • Corrected");
        }

        function cancelR() {
            Swal.fire({
                title: "❌ Cancel / Delete Ride?",
                text: "Are you sure you want to cancel & delete this ride?",
                icon: "question",
                showCancelButton: true,
                confirmButtonColor: "#d33"
            }).then(res => {
                if (res.isConfirmed) {
                    Swal.fire("✅ Ride Cancelled & Deleted!", "Driver notified • Refund done • Ride removed from system", "success");
                    log("❌ RIDE DELETED by Londeka");
                    setTimeout(() => location.reload(), 3500);
                }
            });
        }

        function endR() {
            Swal.fire("🎉 Safe Arrival!", "You arrived safely in Berea!\\nThank you for using Track Shuffle ❤️\\nDUT traffic reduced!", "success");
            log("🏁 Ride completed • 4.9 ⭐ sent");
            setTimeout(() => location.reload(), 3000);
        }

        log("🔥 Google Maps ready • Click buttons to test pop-ups • Zoom the map!");
    </script>
</body>
</html>
    """
    return render_template_string(html,
                                 driver=ride["driver"],
                                 passenger=ride["passenger"],
                                 location=ride["location"],
                                 eta=ride["eta"],
                                 progress=ride["progress"])

# Backend routes (kept for future API integration)
@app.route("/update", methods=["POST"])
def update(): return jsonify({"ok": True})

@app.route("/delay", methods=["POST"])
def delay_route(): return jsonify({"ok": True})

@app.route("/wrong", methods=["POST"])
def wrong_route(): return jsonify({"ok": True})

@app.route("/cancel", methods=["POST"])
def cancel_route(): return jsonify({"ok": True})

@app.route("/end", methods=["POST"])
def end_route(): return jsonify({"ok": True})

if __name__ == "__main__":
    print("🚀 Starting with REAL Google Maps (Steve Biko Campus)...")
    print("Open → http://127.0.0.1:5000")
    print("Click every button → pop-ups appear + map is interactive!")
    app.run(debug=True)